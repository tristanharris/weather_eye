//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TEST VC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTVC_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_USBConnected                129
#define IDB_USBNOTConnected             130
#define IDC_Read                        1000
#define IDC_Address                     1001
#define IDC_Data                        1002
#define IDC_Message                     1004
#define IDC_Picture                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
